# CP1404/5632 Assignment: Reading List by Udaya Bhaskar Reddy Malkannagari

Program Details:

This program simulates a book reading list through a Graphical User Interface(GUI) using the kivy tool kit.
The user can add a new book by entering text in the input fields and clicking the appropriate buttons.The user
can also mark the books as completed. The interface allows to see both the required and the completed books along
with additional data(author name and the number of pages).The books will be saved to the original CSV file along
with their status(required/completed) upon termination the program.

## 1. How long did the entire project (assignment 2) take you?
      The entire project took me about 4 days to complete.It was an exercise for my mind. This project taught me the efficiency of using Object Oriented Programming.
      Understanding the 'Object' characteristics and how they were used in the context of 'Classes' made a very interesting study for me. Initially, I thought
      of using a different approach.I started working on the project without creating the 'Book'and the 'Booklist' classes and tried to implement the code within
      the main 'ReadingListApp' class. It yielded results, but was not effective. Using separate classes and importing them into the main class improved consistency,
      and also helped with further additions. I believe, that this method of working is efficient for future code modifications also. Even though the actual project
      took me around 4 days to finish, I needed more time to understand the OOP principles and implement them within the code structure.

## 2. What are you most satisfied with?
      The most satistying part for me was to realise how cleaner and consistent the code looks with the use of classes and Constructors. For example,during assignment one
      I had to create a function to 'mark' a book as completed in the reading list. With the use of objects, this task became much simpler and efficient. I only had
      to change the 'status' to 'c' within the 'Book' class, and the job was done. This avoided redundancy in the code structure. Passing arguments, for example
      within the Book class, made the code reusable and helped avoiding repetition. I tried to avoid reusing functions and methods as much as possible, and my code structure
      reflects the same. This was the most satisfying part of the exercise for me.

## 3. What are you least satisfied with?
      As I mentioned before,in the initial phase of the project, I tried to use a different approach ignoring the classes 'Book' and 'Booklist' and this set me on a worng track.
      I had to lose valuable time to get it working. Still, I feel, it was learning exercise for me. I learnt from my mistake and followed the basic program structure suggested
      in the Assignment doc. the format was clearly laid out and once I understood the flow of the program, the task became much simpler. The least satistying part
      for me was the error-checking the user inputs when they add a new book to the Booklist. I tried to use try/except method for individual entires but it resulted
      in an endless loop message. Then I used the method of error-checking all the user inputs and then append the book the Booklist object. This was achieved with
      a series of 'if' statements. However, I wasted significant amount of time doing it.

## 4. What worked well in your development process?
      The use of kivy worked extremely well during the development. This was one of the least time consuming parts of the exercise for me. Adding/Removing widgets, clearing the buttons
      for the new user inputs for the adding the book, assigning temporary buttons and binding them to different methods to handle both the 'Required' and Çompleted
      lists was made simpler with the use of kivy tools. The kivy commands were simple to understand as well. For example, i wanted to highlight the 'Required list' button
      as the default starting state of the GUI. I set the button id 'state' to 'down' and used a boolean method to interchange it between the 'Required' and 'Completed' books.
      as done in the press_book() function. This allowed me to highlight the button press for various transformations on the interface. Overall, the use of kivy worked really well
      during this project. The use of github for checking on previous history also worked well during the project.

## 5. What about your process could be improved the next time you do a project like this?
      The next time I would like to create a set path for my project work. This time I had the help of the Assignment document file to help me create the separate classes
      required within the program. I would like to follow the same pattern and split the code into multiple events. I have understood the intricacies of Object Oriented programming
      in python and how every data is the code can be used to interact with other data. The biggest benefit for me was to realise the importance of 'ínstances' in the code. I woluld
      like to take advantage of the 'instance of' relationship and use it effectively for my future projects.This method greatly reduces repetition. One of the OOP principles I would
      like to use in future projects is 'Encapsulation'.Hiding the design details makes the program much more cleaner and consistent for later use. I would like to experiment
      with that principle in the days to come.


## 6. Describe what resources you used and how you used them.
      I used the kivy-demos file provided in the practicals as a base for working on this project. I used the popup-demo and the dynamic widgets examples to understand
      how to integrate the kivy within the main class of the program. For example, in the dynamic widgets, I learnt how to import StringProperty to label status bars
      in the GUI.And also, how to create buttons and add them to the interface. There is a method of 'on-release' that is used to bind the button to an instance. I used this to
      bind my button click to display Required/Comepleted book lists.In the pop-up demo, I learnt how to use handler folr pressing the buttons and incorporated it within
      my code.
      Other resources include practicals materials and our lecture slides. They were helpful during the intial learning phase of the project.

## 7. Describe the main challenges or obstacles you faced and how you overcame them.
      The main challenge for me was the use of separate classes 'Book' and 'Booklist' and how to use them within the main structure of the program. Working on the classes
      was a simple step, but integrating them with the kivy became the tricky part. There was a lot of trial and error that went into refining the code. For example, while using
      the for loop in the display_list function, I was unable to get the exact messages on the label in the GUI. It required a lot of trial and error when I finally got
      it to run, I had to define the message outside the scope of the loop. these were easy but took me some time figuring it out.
      Another example I can give is of the add_new_book function. Appedning the book and adding it to the required list seemed tricky in the beginning.This i accomplished
      by saving the book file and then later adding a new button to the required list. Clearing the inputs was also significant because the text was overwriting if
      I dont use it. These small changes sometimes took me a long time to figure out the solution, but I Believe they enhanced my learning greatly.
... 
