# create your BookList class in this file
"""
BookList class contains a single attribute - a list of Book objects
"""

from book import Book
from operator import attrgetter     #importing the attribute getter from the operator to sort the books


class BookList:
    """ This class represents a book list object"""

    def __init__(self):
        """ This initializes a BookList instance """
        self.booklists = []

    def read_file(self):
        """ This method loads the books from the csv file into Book objects in the list """
        my_file = open("books.csv", 'r')                    # open "books.csv" and read the content
        # for loop that creates a list of Book instances
        for index, data in enumerate(my_file.readlines()):
            datum = data.strip().split(',')                 # using the '.split' method to split each line in the file by the comma
            book = Book(datum[0], datum[1], int(datum[2]), datum[3])  # adding Book instances to the book list
            self.booklists.append(book)
        self.sort_books()                                   # sorting the books based on author and pages
        my_file.close()

    def add_book(self,book = Book()):
        """
        This method appends a book to the booklists
        :param book: book is an instance of the Class 'Book'
        :return: None
        """
        self.booklists.append(book)

    def get_book_by_title(self, title=''):
        """ This method takes in a title (string) and returns the Book object with that title.
            It is used for handling book button clicking """
        for book in self.booklists:
            if book.title == title:
                return book

    def get_total_pages(self, status):
        """
        This method is used to get total pages for required/completed books
        :param status: 'r' or 'c' (required or completed)
        :return: total number of required or completed book pages
        """
        pages = 0       # setting the initial value to 0
        for book in self.booklists:
            if book.status == status:
                pages += int(book.pages)    # adding the number of page to total pages
        return pages



    def write_file(self):
        """
        This method is used to save books from the book list into csv file
        :return: None
        """
        # sort the Book instances in the book list
        self.sort_books()
        # clear the content in the csv file and write the book details from the book list to the file
        output_file = open("books.csv", 'w')
        for book in self.booklists:
            output_file.write('{},{},{},{}\n'.format(book.title, book.author, book.pages, book.status))
        output_file.close()

    def sort_books(self):
        """ This method is used to sort the books in the list,first by author then by the number of pages """
        self.booklists.sort(key=attrgetter('author', 'pages'))










