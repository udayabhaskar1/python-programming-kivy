"""Creating the Book class in this file"""

class Book:
    def __init__(self, title="", author="", pages=0, status=""):
        """ This function is used to construct the Book class"""
        self.title = title
        self.author = author
        self.pages = pages
        self.status = status

    def __str__(self):
        """
        This function is used to display book details
        :return: Details of the book including the author and the number of pages
        """
        return "{} by {},total pages is {}".format(self.title, self.author, self.pages)

    def mark_book(self):
        """
        "This function marks a book on the Required list as completed
        """
        self.status = 'c'

    def long_book(self):
        """
        This function is used to check the length of the book(number of pages)
        :return: True or False
        """
        if self.pages >= 500:
            return True
        else:
            return False
