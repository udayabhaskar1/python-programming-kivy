"""
This program simulates a book reading list through a Graphical User Interface(GUI) using the kivy tool kit.
The user can add a new book by entering text in the input fields and clicking the appropriate buttons.The user
can also mark the books as completed. The interface allows to see both the required and the completed books along
with additional data(author name and the number of pages).

Name: Udaya Bhaskar Reddy Malkannagari
Student ID: 13368171
Date: 29/01/2017
Github Repository Link: https://github.com/mudaybr/CP1404-Assignment2-kivy


"""

from kivy.app import App                    # importing App module from kivy.app library
from kivy.lang import Builder               # importing Builder module from kivy.lang library
from kivy.uix.button import Button          # importing Button module from kivy.uix.button library
from kivy.properties import StringProperty  # importing StringProperty module from kivy.properties library
from book import Book                       # importing Book from the book.py file
from booklist import BookList               # importing BookList from the booklist.py file
from kivy.core.window import Window         # importing Window from the kivy.core.window library
import string                               # importing string module to error check for integers in author name

FILE_NAME = "books.csv"                     # declaring file name as a global constant
__author__ = "Udaya Bhaskar Reddy"          # declaring author name as a global constant
LONG_BOOK_COLOR = (0, 0.9, 1, 1)            # declaring the color of background for long book(pages > 500) as a constant
SHORT_BOOK_COLOR = (0.8, 0.8, 0, 0.9)       # declaring the color of background for short book as a constant
COMPLETED_BOOK_COLOR = (0.4, 0.5, 0.5, 1)   # declaring the color of background for completed book buttons as a constant

class ReadingListApp(App):
    """
    This is the main class that is used for the program. The GUI (using kivy) and other function calls are done through
    this class.
    """

    top_label = StringProperty()
    bottom_label = StringProperty()

    def on_start(self):  # initializing the program
        print("on_start is called.")
        self.press_book("r")   #loading the required book list as the default starting state of the program

    def build(self):
        """
        Build the Kivy GUI
        :return: reference to the root "Kivy" widget
        """
        self.status_text = "Welcome to the Reading List App 2.0"
        self.title = "Reading list 2.0"
        self.root = Builder.load_file("app.kv")
        Window.size = (900,600)  #setting the window size
        return self.root

    def __init__(self, **kwargs):
        """
        Construct main app
        """
        super().__init__(**kwargs)
        self.list_books = BookList() # loading the books from the csv file to the BookList
        self.list_books.read_file()

    def display_list(self, flag):
        """
        This function is used to create the book buttons(required and completed) and adds them to the interface

        :param flag: This argument indicates whether the user chose to list required books or completed books. 'True' denotes
                    required books and 'False' denotes completed books
        :return: None
        """
        self.root.ids.bookDisplay.clear_widgets()  # clear all the book buttons in the bookDisplay using the "clear_widgets()"

        if flag == True:
            for book in self.list_books.booklists:
                if book.status == 'r':
                    temp_button = Button(text=book.title)                  #creating a button for each book on the required list
                    temp_button.bind(on_release=self.handle_required_book) #binding the button to the handle_required_book method
                    if book.long_book():                                   #checking if the book is long(500 pages or more)
                        temp_button.background_color = LONG_BOOK_COLOR     #assigning the background color to the button based on book length
                    else:
                        temp_button.background_color = SHORT_BOOK_COLOR    #assigning the appropriate background color to the button
                    self.root.ids.bookDisplay.add_widget(temp_button)      #adding the button to the bookDisplay interface
            self.bottom_label = "Click books to mark them as completed"    #displaying message in the bottom status bar
            self.top_label = "Total pages to read: {}".format(self.list_books.get_total_pages("r"))
            # displaying the total number of pages in the top status bar by calling the get_total_pages method

        elif flag == False:
            for book in self.list_books.booklists:
                if book.status == 'c':
                    temp_button = Button(text=book.title)                  #creating a button for each book on the completed list
                    temp_button.bind(on_release=self.handle_completed_book)#binding the button on release while pressing
                    temp_button.background_color = COMPLETED_BOOK_COLOR    #setting a background color for completed books
                    self.root.ids.bookDisplay.add_widget(temp_button)      #adding a button to the bookDisplay interface
            self.bottom_label = 'Press the book to know more details'
            self.top_label = "Total pages completed: {}".format(self.list_books.get_total_pages('c'))


    def handle_required_book(self, instance):
        """
        This function is used as a handler for pressing the books buttons in the required list
        :param instance: the Kivy button instance
        :return: None
        """
        title = instance.text
        marked_book = self.list_books.get_book_by_title(title)
        marked_book.mark_book()   # On clicking the book mark it as completed
        self.top_label = "Total pages to read: {}".format(self.list_books.get_total_pages('r'))
        #using the method get_total_pages() to display the total number of pages in the required list after the book is marked as completed
        self.root.ids.bookDisplay.remove_widget(widget=instance) # removing the button of the 'marked book' from the bookDisplay interface

    def handle_completed_book(self, instance):
        """
        This function is used as a handler for pressing the book buttons in the completed list
        :param instance: the kivy button instance
        :return: None
        """
        title = instance.text
        completed_book = self.list_books.get_book_by_title(title)
        self.bottom_label = '{},(completed)'.format(completed_book)
        # displaying the appropriate message for the completed book

    def press_book(self, mode):
        """
        This function highlights the button presses according to the user clicks
        :param mode: This argument indicates whether the user chose to click required books or completed books. 'r' denotes
                    required books and 'c' denotes completed books
        :return: None
        """
        if mode == "r":
            self.display_list(True)                             # Displaying the required list
            self.root.ids.requiredListButton.state = 'down'     # Required Button status while displaying the required list
            self.root.ids.completedListButton.state = 'normal'  # Completed Button status while displaying the required list
        elif mode == "c":
            self.display_list(False)                            # Displaying the completed list
            self.root.ids.requiredListButton.state = 'normal'
            self.root.ids.completedListButton.state = 'down'

    def press_clear(self):
        """
        This function clears out the input text fields for adding a new book
        :return: None
        """
        self.root.ids.bookTitle.text = ''
        self.root.ids.bookAuthor.text = ''
        self.root.ids.bookPages.text = ''

    def press_new_book(self, book_name, author_name, book_pages):
        """
        This function is used as a handler for clicking the 'add' button in the GUI interface to add new books
        It also saves the added book to the file
        :param book_name: user input for the 'Title'
        :param author_name: user input for the 'Author'
        :param book_pages: user input for 'Pages'
        :return: None
        """

        try:                                            # Error checking for incorrect user-inputs
            count = 0                                   # Setting the initial value of count to 0
            for each in str(author_name):               # Looping to check if there are no letters in the author's name
                if each not in (string.ascii_letters + ' '):
                    count += 1                          # increasing the count by 1 if there are no letters and space in author name
            if count > 0:                               # displaying the appropriate message if there are no letters in author name
                self.bottom_label = "Invalid author name; Author name cannot be a number"
            elif book_name == '' or book_name.isspace() or  author_name == '' or author_name.isspace() or book_pages == '':
            # Error-checking for blank user-inputs
                self.bottom_label = "Input cannot be blank"
            elif int(book_pages) <= 0:                  # Checking if the user inputs a negative number for pages
                self.bottom_label = "Number of pages must be greater than 0"
            else:
                added_book = Book(book_name, author_name, int(book_pages), 'r') # creating a Book object for added_book
                self.list_books.add_book(added_book)    # appending the added_book to the list_books attribute
                self.list_books.write_file()            # save a book file when a new book is added
                self.press_book("r")                    # adding a new button for the 'added book' in the required list
                self.press_clear()                      # clearing the text inputs for the next entry
        except ValueError:                              # Error checking for invalid entry for 'Pages'
            self.bottom_label = "Pages must be a number"

    def on_stop(self):                                  # terminating the program
        print('calling on stop')
        self.list_books.write_file()                    # writing the books to the "books.csv" when the program terminates

ReadingListApp().run()


